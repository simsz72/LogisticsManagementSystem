package model;

public enum Role {
    DRIVER, DRIVERMANAGER, ADMIN
}
