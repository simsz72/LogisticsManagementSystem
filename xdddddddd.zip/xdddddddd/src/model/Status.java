package model;

public enum Status {
    PENDING,ONGOING,FINISHED
}
